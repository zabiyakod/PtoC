/*
 * $Id: registerbgifont.c,v 0.1 1993/12/10 00:39:08 king Exp king $
 * Registers lined-in stroked font code.
 *
 * $Log: registerbgifont.c,v $
 * Revision 0.1  1993/12/10  00:39:08  king
 * Initial version.
 *
 */
#include "graphics.h"

int registerbgifont(void *font)
{
/*
 * This routine not currently implemented.
 */
    return 0;
}
