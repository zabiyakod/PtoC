/*
 * $Id: _graphgetmem.c,v 0.1 1993/12/09 23:59:27 king Exp king $
 * User hook into graphics memory allocation.
 *
 * $Log: _graphgetmem.c,v $
 * Revision 0.1  1993/12/09  23:59:27  king
 * Initial version.  __graphgetmem not currently implemented.
 *
 */
#include "graphics.h"

void *_graphgetmem(unsigned int size)
{
/*
 * This routine not currently implemented.
 */
    return NULL;
}
