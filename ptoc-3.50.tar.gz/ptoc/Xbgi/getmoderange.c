/* 
 * $Id: getmoderange.c,v 0.1 1993/12/10 00:15:31 king Exp king $ 
 * Gets the range of modes for a given graphics driver.
 *
 * $Log: getmoderange.c,v $
 * Revision 0.1  1993/12/10  00:15:31  king
 * Initial version.
 *
 */
#include "graphics.h"

void getmoderange(int graphdriver, int *lomode, int *himode)
{

}
