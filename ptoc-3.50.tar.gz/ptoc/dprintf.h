char *dprintf (const char *fmp, ...);
