#include "graphics.h"

void delay(int msec)
{
    usleep(msec*1000);
}


