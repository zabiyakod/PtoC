/*
 * $Id: setgraphmode.c,v 0.1 1993/12/10 00:39:08 king Exp king $
 * Sets the system to graphics mode and clears the screen.
 *
 * $Log: setgraphmode.c,v $
 * Revision 0.1  1993/12/10  00:39:08  king
 * Initial version.
 *
 */
#include "graphics.h"

void setgraphmode(int mode)
{
/*
 * This routine not currently implemented.
 */
}
