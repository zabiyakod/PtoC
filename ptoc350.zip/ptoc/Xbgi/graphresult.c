/*
 * $Id: graphresult.c,v 0.1 1993/12/10 00:37:39 king Exp king $
 * Returns an error code for the last unsuccessfull graphics operation.
 *
 * $Log: graphresult.c,v $
 * Revision 0.1  1993/12/10  00:37:39  king
 * Initial version.
 *
 */
#include "graphics.h"

int graphresult(void)
{
        return 0;
}
