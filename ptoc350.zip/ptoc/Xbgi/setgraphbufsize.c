/*
 * $Id: setgraphbufsize.c,v 0.1 1993/12/10 00:39:08 king Exp king $
 * Changes the size of the internal graphics buffer.
 *
 * $Log: setgraphbufsize.c,v $
 * Revision 0.1  1993/12/10  00:39:08  king
 * Initial version.
 *
 */
#include "graphics.h"

unsigned int setgraphbufsize(unsigned int bufsize)
{
/*
 * This routine not currently implemented.
 */
    return 0;
}
