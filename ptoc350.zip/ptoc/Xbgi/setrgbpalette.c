/*
 * $Id: setrgbpalette.c,v 0.1 1993/12/10 00:39:08 king Exp king $
 * Allows the user to define colours for the IBM 8514.
 *
 * $Log: setrgbpalette.c,v $
 * Revision 0.1  1993/12/10  00:39:08  king
 * Initial version.
 *
 */
#include "graphics.h"

void setrgbpalette(int colornum, int red, int green, int blue)
{
/*
 * This routine not currently implemented.
 */
}
